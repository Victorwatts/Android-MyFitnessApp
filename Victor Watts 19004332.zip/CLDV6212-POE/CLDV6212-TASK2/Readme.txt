How to access the web application.
--------------------------------------
User
--------------------------------------
1. https://cloud6212-task220201013170007.azurewebsites.net/
2. Follow the link provided above.
3. You will find yourself on the user login screen. This screen is for general users that will be shopping to login.
4. If the user does not have an account, they can either click on the "Register new user" button or sellect register in the nav bar.
5. To register, fill in all the required information and click register.
6. Once a user has lloged in, they will be taken to the store page.
7. From the store page, they can view all the products and add them to their cart by clicking the add to cart button.
8. The user can view the amount of items in their cart by looking at the number next to the cart in the nav bar.
9. A user can click on the cart in the nav bar to view all their added items.
10. The user can remove an item by clicking on the remove item button.
11. The user can then either click on the checkout button or the checkout in the nav bar.
12. At the checkout page they will see the total cost of all the items, where they can then click pay.
13. The user can logout at anytime by clicking the logout button.
<!- If the nav bar on the user login page are not working, click on the "Register new user" button and then the nav bar will work perfectly fine -!>
--------------------------------------
Admin
--------------------------------------
1. https://cloud6212-task220201013170007.azurewebsites.net/
2. Follow the link provided above.
3. You will find yourself on the user login screen. This screen is for general users that will be shopping to login.
4. Admin will click on the administration button in the nav bar.
5. This will bring them to a login page. If the admin needs to register an account  they can either click on the "Register new user" button or sellect register in the nav bar.
6. To register, fill in all the required information and click register.
7. To register an admin, an authorisation code will be needed (CLOUD6212).
8. Once the admin has logged in, they will be on the add new items page.
9. From here the admin can add new items, by giving an item name, description and price. The admin will click on choose file to select the product image.
10. Once the image is selected, the admin can click add item to add the new item.
11. Clicking on edit products in the nav bar will direct the admin to the edit products page. Here they will have a table containing all the stored products.
12. On this page an admin can edit a product details or just delete the entire instance of the product.
13. The admin can logout at anytime by clicking the logout button.

--------------------------------------
URL URL URL URL URL URL URL URL URL URL
--------------------------------------
https://cloud6212-task220201013170007.azurewebsites.net/
--------------------------------------
URL URL URL URL URL URL URL URL URL URL
--------------------------------------

--------------------------------------
---------authorisation code-----------
--------------------------------------
CLOUD6212
--------------------------------------
---------authorisation code-----------
--------------------------------------




