﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CLOUD6212_TASK2
{
    public partial class loginForm : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            using (SqlConnection con = new SqlConnection(Properties.Settings.Default.connString))
            {

                SqlCommand cmd = new SqlCommand("SELECT * FROM ADMININFO WHERE Admin_Username = @Username AND Admin_Password = @Password ", con);
                cmd.Parameters.AddWithValue("@Username", TextBox1.Text);
                cmd.Parameters.AddWithValue("@Password", TextBox2.Text);

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                con.Open();
                int i = cmd.ExecuteNonQuery();
                con.Close();

                //Fetches the username and password from the DB

                if (dt.Rows.Count == 1)
                {

                    foreach (DataRow row in dt.Rows)
                    {
                        Session["ADMIN"] = row["ADMINISTRATION_ID"];
                    }
                    Response.Redirect("~/Forms/AddItems.aspx");
                    
                    //saves the user name so that it indicates on the top of each page 
                    //it also is used to give access and deny access to specific controls
                }
                else
                {
                    Label3.Text = "Your username and Password are incorrect";
                    Label3.ForeColor = System.Drawing.Color.Red;
                    //error messege if details are wrong
                }
            }

        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Forms/RegisterForm.aspx");
        }
    }
}
    
