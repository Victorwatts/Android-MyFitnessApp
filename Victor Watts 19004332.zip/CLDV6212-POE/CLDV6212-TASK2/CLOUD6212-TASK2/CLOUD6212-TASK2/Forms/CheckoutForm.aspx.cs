﻿using System;
using System.Data.SqlClient;
using System.Web;

namespace CLOUD6212_TASK2.Forms
{
    public partial class CheckoutForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            Response.Cache.SetExpires(DateTime.MinValue);

            base.OnInit(e);

            //checks a user is logged in
            if (Session["USER"] == null)
            {
                Response.Redirect("~/Forms/UserLogin.aspx");
            }
            else
                //gets user name
                using (SqlConnection con = new SqlConnection(Properties.Settings.Default.connString))
                {
                    int str = (int)Session["USER"];
                    SqlCommand cmdUser = new SqlCommand("Select Username from USERS where User_ID = @User_ID", con);
                    cmdUser.Parameters.AddWithValue("@User_ID", str);
                    try

                    {
                        con.Open();
                        string user = (string)cmdUser.ExecuteScalar();
                        con.Close();
                        Label3.Text = user;
                    }
                    catch (Exception)
                    {

                    }
                }
            // calculates total cost of all products
            using (SqlConnection con = new SqlConnection(Properties.Settings.Default.connString))
            {
                int str = (int)Session["USER"];
                SqlCommand cmdSUM = new SqlCommand("Select SUM(PRODUCT_PRICE) from PRODUCTS A, CART B where A.PRODUCT_ID = B.PRODUCT_ID AND  User_ID = @User_ID", con);
                cmdSUM.Parameters.AddWithValue("@User_ID", str);
                try

                {
                    con.Open();
                    int SUM = (int)cmdSUM.ExecuteScalar();
                    con.Close();
                    Label1.Text = SUM.ToString();

                }
                catch (Exception)
                {
                    Label2.Text = "Add Items To Cart First";
                    Label2.ForeColor = System.Drawing.Color.Red;
                }
            }

        }
        //pay
        protected void Button1_Click(object sender, EventArgs e)
        {
            Label2.Text = "PAYMENT SUCCESSFUL";
            Label2.ForeColor = System.Drawing.Color.Green;
        }

       //logout
        protected void Button2_Click1(object sender, EventArgs e)
        {
            Session["USER"] = null;
            Response.Redirect("~/Forms/UserLogin.aspx");
        }
    }
}