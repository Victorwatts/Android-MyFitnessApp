﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace CLOUD6212_TASK2.Forms
{
    public partial class MainStore : System.Web.UI.Page
    {

        public string PRODUCT_IMAGE { get; set; }
        public string Product_Name { get; set; }
        public string PRODUCT_DESCRIPTION { get; set; }
        public int PRODUCT_PRICE { get; set; }
        public int ID { get; set; }


        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            Response.Cache.SetExpires(DateTime.MinValue);

            base.OnInit(e);

            //checks that a user is logged in
            if (Session["USER"] == null)
            {
                Response.Redirect("~/Forms/UserLogin.aspx");
            }else

                //sets the username
            using (SqlConnection con = new SqlConnection(Properties.Settings.Default.connString))
            {
                int str = (int)Session["USER"];
                SqlCommand cmdUser = new SqlCommand("Select Username from USERS where User_ID = @User_ID", con);
                cmdUser.Parameters.AddWithValue("@User_ID", str);
                try

                {
                    con.Open();
                    string user = (string)cmdUser.ExecuteScalar();
                    con.Close();
                    Label3.Text = user;
                }
                catch (Exception)
                {
                   
                }

                    //gets the count of items in the users cart
                SqlCommand cmdCount = new SqlCommand("Select COUNT(User_ID) from CART where User_ID = @User_ID", con);
                cmdCount.Parameters.AddWithValue("@User_ID", str);
                try

                {
                    con.Open();
                    int Count = (int)cmdCount.ExecuteScalar();
                    con.Close();
                    Label1.Text = Count.ToString();
                }
                catch (Exception)
                {
                    Label2.Text = "Error";
                    Label2.ForeColor = System.Drawing.Color.Red;
                }
            }

            // gets and displays all the saved products
            using (SqlConnection con = new SqlConnection(Properties.Settings.Default.connString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT PRODUCT_ID, Product_Name, PRODUCT_DESCRIPTION, PRODUCT_PRICE, PRODUCT_IMAGE from PRODUCTS", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                cmd.CommandType = CommandType.Text;
                DataTable dt = new DataTable();
                sda.Fill(dt);

                int count = 0;
                //dynamically add the products and the needed controls to the website using a repeater
                System.Web.UI.HtmlControls.HtmlGenericControl createRow = new System.Web.UI.HtmlControls.HtmlGenericControl("DIV");
                createRow.Attributes.Add("class", "row");
                Form.Controls.Add(createRow);
                foreach (DataRow row in dt.Rows)
                {
                    byte[] bytes = (byte[])row["PRODUCT_IMAGE"];
                    string strBase64 = Convert.ToBase64String(bytes);
                    PRODUCT_IMAGE = "data:Image/png;base64," + strBase64;
                    Product_Name = row["Product_Name"].ToString();
                    PRODUCT_DESCRIPTION = row["PRODUCT_DESCRIPTION"].ToString();
                    PRODUCT_PRICE = Convert.ToInt16(row["PRODUCT_PRICE"]);
                    ID = Int32.Parse(row["PRODUCT_ID"].ToString());
                    Button Slct = new Button();
                    Slct.Text = "Add To Cart";
                    Slct.ID = row["PRODUCT_ID"].ToString();
                    Slct.Click += new EventHandler(btnclick_Click);
                    Label ITEM = new Label();
                    ITEM.Font.Underline = true;
                    ITEM.Text = "ITEM NAME";
                    Label DESC = new Label();
                    DESC.Font.Underline = true;
                    DESC.Text = "DESCRIPTION";
                    Label Price = new Label();
                    Price.Font.Underline = true;
                    Price.Text = "PRICE: ";
                    Label UNIT = new Label();
                    UNIT.Text = "R";
                    Label lb1 = new Label();
                    lb1.Text = row["Product_Name"].ToString();
                    Label lb2 = new Label();
                    lb2.Text = row["PRODUCT_DESCRIPTION"].ToString();
                    Label lb3 = new Label();
                    lb3.Text = row["PRODUCT_PRICE"].ToString();
                    Image tb = new Image();
                    Label ItemID = new Label();
                    ItemID.Text = ID.ToString();
                    tb.ImageUrl = "data:Image/png;base64," + strBase64;
                    tb.Attributes.Add("class", "img");
                    System.Web.UI.HtmlControls.HtmlGenericControl createDiv = new System.Web.UI.HtmlControls.HtmlGenericControl("DIV");
                    System.Web.UI.HtmlControls.HtmlGenericControl cardDiv = new System.Web.UI.HtmlControls.HtmlGenericControl("DIV");
                    createDiv.Attributes.Add("class", "column");
                    cardDiv.Attributes.Add("class", "card");
                    createRow.Controls.Add(createDiv);
                    createDiv.Controls.Add(cardDiv);
                    cardDiv.Controls.Add(tb);
                    cardDiv.Controls.Add(new LiteralControl("<br />"));
                    cardDiv.Controls.Add(new LiteralControl("<br />"));
                    cardDiv.Controls.Add(ITEM);
                    cardDiv.Controls.Add(new LiteralControl("<br />"));
                    cardDiv.Controls.Add(lb1);
                    cardDiv.Controls.Add(new LiteralControl("<br />"));
                    cardDiv.Controls.Add(new LiteralControl("<br />"));
                    cardDiv.Controls.Add(DESC);
                    cardDiv.Controls.Add(new LiteralControl("<br />"));
                    cardDiv.Controls.Add(lb2);
                    cardDiv.Controls.Add(new LiteralControl("<br />"));
                    cardDiv.Controls.Add(new LiteralControl("<br />"));
                    cardDiv.Controls.Add(Price);
                    cardDiv.Controls.Add(new LiteralControl("&nbsp;"));
                    cardDiv.Controls.Add(UNIT);
                    cardDiv.Controls.Add(lb3);
                    cardDiv.Controls.Add(new LiteralControl("<br />"));
                    cardDiv.Controls.Add(new LiteralControl("<br />"));
                    cardDiv.Controls.Add(Slct);
                    count++;

                }



                con.Close();





            }

        }



        protected void btnclick_Click(object sender, EventArgs e)
        {

            Button button = (Button)sender;
            string buttonId = button.ID;
            Label2.Text = buttonId;
            int str = (int)Session["USER"];
            //add items to the cart
            using (SqlConnection con = new SqlConnection(Properties.Settings.Default.connString))
            {

                SqlCommand cmdUser = new SqlCommand("Insert into Cart (User_ID,Product_ID) VALUES (@User_ID, @Product_ID)", con);
                cmdUser.Parameters.AddWithValue("@User_ID", str);
                cmdUser.Parameters.AddWithValue("@Product_ID", buttonId);



                cmdUser.CommandType = CommandType.Text;
                try

                {
                    con.Open();
                    cmdUser.ExecuteNonQuery();
                    con.Close();
                    Label2.Text = "Item Added";
                    Label2.ForeColor = System.Drawing.Color.Green;

                    SqlCommand cmdCount = new SqlCommand("Select COUNT(User_ID) from CART where User_ID = User_ID", con);
                    cmdCount.Parameters.AddWithValue("@User_ID", str);
                    try

                    {
                        con.Open();
                        int Count = (int)cmdCount.ExecuteScalar();
                        con.Close();
                        Label1.Text = Count.ToString();
                    }
                    catch (Exception)
                    {
                        Label2.Text = "Error";
                        Label2.ForeColor = System.Drawing.Color.Red;
                    }
                }

                catch (Exception)

                {
                    Label2.Text = "Error";
                    Label2.ForeColor = System.Drawing.Color.Red;

                }
            }
        }
        //logout
        protected void Button1_Click1(object sender, EventArgs e)
        {
            Session["USER"] = null;
            Response.Redirect("~/Forms/UserLogin.aspx");
        }
    }
}




