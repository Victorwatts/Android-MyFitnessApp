﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Web;
using static WinFormAnimation.AnimationFunctions;

namespace CLOUD6212_TASK2
{
    public partial class AddItems : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            Response.Cache.SetExpires(DateTime.MinValue);

            base.OnInit(e);


            //checks that an admin is logged in
            if (Session["ADMIN"] == null)
            {
                Response.Redirect("~/Forms/loginForm.aspx");
            }
            else
                // gets username
                using (SqlConnection con = new SqlConnection(Properties.Settings.Default.connString))
                {
                    int str = (int)Session["ADMIN"];
                    SqlCommand cmdUser = new SqlCommand("Select Admin_Username from ADMININFO where Administration_ID = @User_ID", con);
                    cmdUser.Parameters.AddWithValue("@User_ID", str);
                    try

                    {
                        con.Open();
                        string user = (string)cmdUser.ExecuteScalar();
                        con.Close();
                        Label1.Text = user;
                    }
                    catch (Exception)
                    {

                    }
                }
        }


        protected void ItemName_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ItemPrice_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ItemDescription_TextChanged(object sender, EventArgs e)
        {

        }

        protected void SearchProduct_TextChanged(object sender, EventArgs e)
        {

        }
        //validates product details
        public void InputValidation()
        {
            if (ItemName.Text == "")
            {
                Label3.Text = "Enter an item name!";
                Label3.ForeColor = System.Drawing.Color.Red;
                return;
            }

            else if (ItemDescription.Text == "")
            {
                Label3.Text = "Enter an item description!";
                Label3.ForeColor = System.Drawing.Color.Red;
                return;
            }

            else if (ItemDescription.Text == "")
            {
                Label3.Text = "Enter an item price!";
                Label3.ForeColor = System.Drawing.Color.Red;
                return;
            }

            else if (!FileUpload1.HasFile)
            {
                Label3.Text = "Add an item image!";
                Label3.ForeColor = System.Drawing.Color.Red;
                return;
            }else
            data();

        }

        //saves product to the db
        public void data()
        {
            using (SqlConnection con = new SqlConnection(Properties.Settings.Default.connString))
            {
                SqlCommand cmd = new SqlCommand("Insert into PRODUCTS (PRODUCT_NAME,PRODUCT_DESCRIPTION,PRODUCT_PRICE,PRODUCT_IMAGE) VALUES (@itemname, @tiemdesc, @itemprice, @itemimg)", con);
                cmd.Parameters.AddWithValue("@itemname", ItemName.Text);
                cmd.Parameters.AddWithValue("@tiemdesc", ItemDescription.Text);
                cmd.Parameters.AddWithValue("@itemprice", ItemPrice.Text);
                int Length = FileUpload1.PostedFile.ContentLength;
                byte[] pic = new byte[Length];
                FileUpload1.PostedFile.InputStream.Read(pic, 0, Length);
                cmd.Parameters.AddWithValue("@itemimg", pic);

                cmd.CommandType = CommandType.Text;
                try

                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    Label3.Text = "Item successfully added";
                    Label3.ForeColor = System.Drawing.Color.Green;
                   
                }

                catch (Exception)

                {
                    Label3.Text = "Error";
                    Label3.ForeColor = System.Drawing.Color.Red;

                }


            }
        }
     



        protected void BtnAddItem_Click(object sender, EventArgs e)
        {
            
            InputValidation();
            
           

        }


        //protected void btnTest_Click(object sender, EventArgs e)
        //{
        //    using (SqlConnection con = new SqlConnection(Properties.Settings.Default.connString))
        //    {
        //        SqlCommand cmd = new SqlCommand("SELECT PRODUCT_IMAGE FROM PRODUCTS WHERE PRODUCT_NAME = @productname", con);
        //        cmd.Parameters.AddWithValue("@productname", SearchProduct.Text);
        //        cmd.CommandType = CommandType.Text;

        //        con.Open();
        //        byte[] bytes = (byte[])cmd.ExecuteScalar();
        //        string strBase64 = Convert.ToBase64String(bytes);
        //        Image1.ImageUrl = "data:Image/png;base64," + strBase64;
        //        con.Close();
        //    }
        //}

        //logout
        protected void Button1_Click(object sender, EventArgs e)
        {

            Session["ADMIN"] = null;
            Response.Redirect("~/Forms/loginForm.aspx");
        }


    }
}